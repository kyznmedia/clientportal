/*
 Navicat Premium Data Transfer

 Source Server         : KYZN Datalake - d5ai5b0olqkbot
 Source Server Type    : PostgreSQL
 Source Server Version : 90603
 Source Host           : ec2-54-81-97-25.compute-1.amazonaws.com
 Source Database       : d5ai5b0olqkbot
 Source Schema         : datalake

 Target Server Type    : PostgreSQL
 Target Server Version : 90603
 File Encoding         : utf-8

 Date: 12/14/2017 11:08:33 AM
*/

-- ----------------------------
--  Table structure for jotform_aande
-- ----------------------------
DROP TABLE IF EXISTS "datalake"."jotform_aande";
CREATE TABLE "datalake"."jotform_aande" (
	"event_id" varchar NOT NULL COLLATE "default",
	"reportType" varchar COLLATE "default",
	"brandprimary" varchar COLLATE "default",
	"brandsecondary" varchar COLLATE "default",
	"products" varchar COLLATE "default",
	"keyexec" varchar COLLATE "default",
	"brandaor" varchar COLLATE "default",
	"digitalagency" varchar COLLATE "default",
	"mediaagency" varchar COLLATE "default",
	"campaignbudget" varchar COLLATE "default",
	"gender" varchar COLLATE "default",
	"age" varchar COLLATE "default",
	"worked" varchar COLLATE "default",
	"buy" varchar COLLATE "default",
	"buydetails" varchar COLLATE "default",
	"aande" varchar COLLATE "default",
	"additionalinfo" varchar COLLATE "default",
	"brandassets" varchar COLLATE "default",
	"pitchfiles" varchar COLLATE "default"
)
WITH (OIDS=FALSE);
ALTER TABLE "datalake"."jotform_aande" OWNER TO "udn061oqvdillp";

-- ----------------------------
--  Primary key structure for table jotform_aande
-- ----------------------------
ALTER TABLE "datalake"."jotform_aande" ADD PRIMARY KEY ("event_id") NOT DEFERRABLE INITIALLY IMMEDIATE;
