from flask import Flask, request, render_template, redirect, url_for, make_response
import os, requests, json
from datetime import datetime, timedelta
import psycopg2
import psycopg2.extensions
import psycopg2.extras
from cryptography.x509 import load_pem_x509_certificate
from cryptography.hazmat.backends import default_backend
from jose import jwt


app = Flask(__name__, static_url_path='/static')

# object helper
def returnVal(obj, name):
    try:
        if isinstance(obj[name],list):
            data = [x.encode('UTF8') for x in obj[name]]
            return ', '.join(data)
        elif 'date' in name:
            return str(obj[name]['year']) + '-' + str(obj[name]['month']) + '-' + str(obj[name]['day'])
        else:
            data = str(obj[name])
            return (data[:9000] + '..') if len(data) > 9000 else data
    except:
        return None

@app.route("/")
def hello():
    return "There is no UI."

@app.route("/outbound")
def out():
    # load auth0 info
    jsonurl = requests.get("https://kyzn.auth0.com/.well-known/jwks.json")
    jwks = json.loads(jsonurl.text)
    cert = '-----BEGIN CERTIFICATE-----\n' + jwks['keys'][0]['x5c'][0] + '\n-----END CERTIFICATE-----'

    certificate = load_pem_x509_certificate(str(cert), default_backend())
    publickey = certificate.public_key()

    JWT_AUTH = {
        'JWT_PAYLOAD_GET_USERNAME_HANDLER':
            'authorization.user.jwt_get_username_from_payload_handler',
        'JWT_PUBLIC_KEY': publickey,
        'JWT_ALGORITHM': 'RS256',
        'JWT_AUDIENCE': 'HesQKqwyZ07bu3ebdVBjCvd1tewT4gqG',
        'JWT_ISSUER': 'kyzn.auth0.com',
        'JWT_AUTH_HEADER_PREFIX': 'Bearer',
    }

    usertoken = request.args.get('usertoken')
    projectid = request.args.get('projectid')
    if usertoken:
        try:
            token_check = jwt.get_unverified_claims(usertoken)
        except:
            token_check = False
            data = {"message" : "not authenticated"}

        if token_check:
            db_settings = {"port": os.environ['DATABASE_PORT'], "host": os.environ['DATABASE_HOST'], "password": os.environ['DATABASE_PW'], "user": os.environ['DATABASE_USER'], "database": os.environ['DATABASE_DB']}
            conn = psycopg2.connect(**db_settings)
            cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)
            print(token_check)

            if projectid:
                payload = {
                    "resource": {"dashboard": 6},
                    "params": {
                        "email": token_check['email']
                    }
                }
                token = jwt.encode(payload, os.environ['METABASE_SECRET_KEY'], algorithm="HS256")
                iframeUrl = os.environ['METABASE_SITE_URL'] + "/embed/dashboard/" + token + "#bordered=false&titled=false"
                data = {}
                data['metabase'] = iframeUrl

            else:
                cur.execute("""
                SELECT event_id, "reportType", brandprimary, products, duedate
                from datalake.jotform_aande
                where email = %s
                """,(token_check['email'],))
                data = cur.fetchall()

            conn.close()

        resp = app.make_response(json.dumps(data))
        resp.headers['Access-Control-Allow-Origin'] = '*'
        resp.headers['Access-Control-Expose-Headers'] = 'Access-Control-Allow-Origin'
        resp.headers['Access-Control-Allow-Headers'] = 'Origin, X-Requested-With, Content-Type, Accept'
        resp.headers['Content-type'] = 'application/json'
        return resp
    else:
        return "There is no UI."

# TODO UPDATE BASED ON NEW SCHEMA
@app.route("/incoming", methods = ['POST'])
def webhook():
    formID = request.form.get('formID')
    rawRequest = request.form.get('rawRequest')
    if formID and rawRequest and formID == '73466946103157':
        request_body = json.loads(rawRequest)

        db_settings = {"port": os.environ['DATABASE_PORT'], "host": os.environ['DATABASE_HOST'], "password": os.environ['DATABASE_PW'], "user": os.environ['DATABASE_USER'], "database": os.environ['DATABASE_DB']}
        conn = psycopg2.connect(**db_settings)
        cur = conn.cursor()
        print "Request received: " + json.dumps(request_body)

        cur.execute("""
        INSERT INTO datalake.jotform_aande (
        	"event_id",
        	"reportType",
        	"brandprimary",
        	"brandsecondary",
        	"products",
        	"keyexec",
        	"brandaor",
        	"digitalagency",
        	"mediaagency",
        	"campaignbudget",
        	"gender",
        	"age",
        	"worked",
        	"buy",
        	"buydetails",
        	"aande",
        	"additionalinfo",
        	"brandassets",
        	"pitchfiles",
            "duedate",
            "name",
            "email")
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
        """,(
        returnVal(request_body,"event_id"),
        returnVal(request_body,"q4_reportType"),
        returnVal(request_body,"q7_brandPrimary"),
        returnVal(request_body,"q9_brandSecondary"),
        returnVal(request_body,"q10_products"),
        returnVal(request_body,"q11_keybrandexecutives"),
        returnVal(request_body,"q12_brandaor"),
        returnVal(request_body,"q13_digitalagency"),
        returnVal(request_body,"q14_mediaAgency"),
        returnVal(request_body,"q17_campaignBudget"),
        returnVal(request_body,"q18_gender"),
        returnVal(request_body,"q19_age"),
        returnVal(request_body,"q23_worked"),
        returnVal(request_body,"q25_buy"),
        returnVal(request_body,"q26_buydetails"),
        returnVal(request_body,"q31_aandenetworks"),
        returnVal(request_body,"q32_additionalInformation"),
        returnVal(request_body,"brandAssets"),
        returnVal(request_body,"typeA29"),
        returnVal(request_body,"q35_duedate"),
        returnVal(request_body,"q36_name"),
        returnVal(request_body,"q37_email")
        ))
        conn.commit()

        conn.close()
        return "OK"
    else:
        return redirect('/')


if __name__ == "__main__":
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=True)
